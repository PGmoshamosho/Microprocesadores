#include <xc.h>

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

volatile unsigned char duty_led2 = 0;
volatile unsigned char contador_pwm = 0;

void ADC_Init(){
    ADCON0 = 0x81;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(unsigned char canal){
    ADCON0 = (canal << 2) | 0x01;
    __delay_us(20);

    GO_nDONE = 1;
    while(GO_nDONE);

    return ((ADRESH << 8) + ADRESL);
}

void PWM_Hardware_Init(){
    TRISCbits.TRISC2 = 0;

    PR2 = 255;
    CCP1CON = 0x0C;

    CCPR1L = 0;
    CCP1CONbits.DC1B = 0;

    T2CON = 0x04;
}

void PWM_Hardware_Duty(unsigned int duty){
    if(duty > 1023){
        duty = 1023;
    }

    CCPR1L = duty >> 2;
    CCP1CONbits.DC1B = duty & 0x03;
}

void Timer1_Init(){
    T1CON = 0x01;

    TMR1H = 0xFF;
    TMR1L = 0x38;

    TMR1IF = 0;
    TMR1IE = 1;
    PEIE = 1;
    GIE = 1;
}

void __interrupt() ISR(){
    if(TMR1IF){
        TMR1H = 0xFF;
        TMR1L = 0x38;

        contador_pwm++;

        if(contador_pwm >= 100){
            contador_pwm = 0;
        }

        if(contador_pwm < duty_led2){
            PORTDbits.RD0 = 1;
        }
        else{
            PORTDbits.RD0 = 0;
        }

        TMR1IF = 0;
    }
}

void main(void){
    unsigned int pot1;
    unsigned int pot2;

    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA1 = 1;

    TRISDbits.TRISD0 = 0;
    PORTDbits.RD0 = 0;

    ADC_Init();
    PWM_Hardware_Init();
    Timer1_Init();

    while(1){
        pot1 = ADC_Read(0);
        pot2 = ADC_Read(1);

        PWM_Hardware_Duty(pot1);

        duty_led2 = (pot2 * 100) / 1023;

        __delay_ms(20);
    }
}
