#include <xc.h>

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

void ADC_Init(){
    ANSEL = 0x03;
    ANSELH = 0x00;

    ADCON0 = 0x81;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(unsigned char canal){
    ADCON0 = (canal << 2) | 0x01;
    __delay_us(20);

    GO_nDONE = 1;
    while(GO_nDONE);

    return ((ADRESH << 8) + ADRESL);
}

void PWM_Init(){
    TRISCbits.TRISC2 = 0;

    PR2 = 255;
    CCP1CON = 0x0C;

    CCPR1L = 0;
    CCP1CONbits.DC1B = 0;

    T2CON = 0x04;
}

void PWM_Duty(unsigned int duty){
    if(duty > 1023){
        duty = 1023;
    }

    CCPR1L = duty >> 2;
    CCP1CONbits.DC1B = duty & 0x03;
}

void main(void){
    unsigned int velocidad;
    unsigned int giro;

    ADC_Init();
    PWM_Init();

    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA1 = 1;

    TRISCbits.TRISC0 = 0;
    TRISCbits.TRISC1 = 0;
    TRISCbits.TRISC2 = 0;

    PORTCbits.RC0 = 0;
    PORTCbits.RC1 = 0;

    while(1){
        velocidad = ADC_Read(0);
        giro = ADC_Read(1);

        PWM_Duty(velocidad);

        if(giro < 400){

            PORTCbits.RC0 = 1;
            PORTCbits.RC1 = 0;
        }
        else if(giro > 600){
            PORTCbits.RC0 = 0;
            PORTCbits.RC1 = 1;
        }
        else{
            PORTCbits.RC0 = 0;
            PORTCbits.RC1 = 0;
        }

        __delay_ms(20);
    }
}
