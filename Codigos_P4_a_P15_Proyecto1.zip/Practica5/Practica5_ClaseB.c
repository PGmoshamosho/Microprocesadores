#include <xc.h> // Biblioteca principal del compilador XC8

#pragma config FOSC = XT
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000
#define LED PORTCbits.RC0

unsigned char patron[10]={
	0x3F,
	0x6,
	0x5B,
	0x4F,
	0x66,
	0x6D,
	0x7D,
	0x7,
	0x7F,
	0x67,
};

void blink_led(){
	for(int i = 0; i < 4; i++){
		LED = 1;
		__delay_ms(500);
		LED = 0;
		__delay_ms(500);
	}
}

void main(void){
	ANSEL = 0;
	ANSELH = 0;
	OPTION_REG = OPTION_REG & 0b01111111;

	TRISC = 0;
	TRISD = 0;
	TRISB = 0xFF;

	PORTC = 0;
	PORTD = 0;

	unsigned char count = 0;

	GIE = 1;//ACTIVAR TODAS LAS INTERRUPCIONES
	INTE = 1;
	INTEDG = 0;

	while(1){
		PORTD = patron[count];
		count = (count + 1)%10;
		__delay_ms(500);
	}
}

void __interrupt() ISR(void){
	if(INTF){
		GIE = 0;//DESACTIVAR TODAS LAS INTERRUPCIONES
		blink_led(); //ejecutar las funciones de la interrupcion
		GIE = 1;
		INTF = 0;
	}
}
