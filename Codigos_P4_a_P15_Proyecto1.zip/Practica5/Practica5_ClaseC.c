#include <xc.h> // Biblioteca principal del compilador XC8

#pragma config FOSC = XT
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000
#define LED PORTCbits.RC0

unsigned char patron[10]={
	0x3F,
	0x6,
	0x5B,
	0x4F,
	0x66,
	0x6D,
	0x7D,
	0x7,
	0x7F,
	0x67,
};

int num = 0;
unsigned char direccion = 1;
unsigned char cambio = 0;

void mostrar_numero(int numero){
	int millar = numero / 1000;
	int centena = (numero / 100) % 10;
	int decena = (numero / 10) % 10;
	int unidad = numero % 10;

	PORTC = 0b11111110;
	PORTD = patron[millar];
	__delay_ms(1);

	PORTC = 0b11111101;
	PORTD = patron[centena];
	__delay_ms(1);

	PORTC = 0b11111011;
	PORTD = patron[decena];
	__delay_ms(1);

	PORTC = 0b11110111;
	PORTD = patron[unidad];
	__delay_ms(1);
}

void main(void){
	ANSEL = 0;
	ANSELH = 0;
	OPTION_REG = OPTION_REG & 0b01111111;

	TRISD = 0;
	TRISC = 0;
	TRISB = 0xFF;

	PORTD = 0;
	PORTC = 0x0F;

	INTF = 0;
	GIE = 1;
	INTE = 1;
	INTEDG = 0;

	while(1){

		for(int i = 0; i < 15; i++){
			mostrar_numero(num);
		}

		if(cambio == 1){
			direccion = !direccion;
			cambio = 0;

			for(int j = 0; j < 20; j++){
				mostrar_numero(num);
			}

			INTF = 0;
			INTE = 1;
		}

		if(direccion == 1){
			num++;

			if(num == 10000){
				num = 0;
			}
		}
		else{
			num--;

			if(num < 0){
				num = 9999;
			}
		}
	}
}

void __interrupt() ISR(void){
	if(INTF){
		INTE = 0;
		cambio = 1;
		INTF = 0;
	}
}
