#include <xc.h> // Biblioteca principal del compilador XC8

#pragma config FOSC = XT
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

unsigned char patron[10]={
	0x3F,
	0x6,
	0x5B,
	0x4F,
	0x66,
	0x6D,
	0x7D,
	0x7,
	0x7F,
	0x67,
};

void main(void){
	TRISD = 0;
	TRISC = 0;

	PORTD = 0;
	PORTC = 0x0F;

	int num = 0;

	while(1){
		int millar = num / 1000;
		int centena = (num / 100) % 10;
		int decena = (num / 10) % 10;
		int unidad = num % 10;

		for(int i = 0; i < 30; i++){

			PORTC = 0b11111110; // Display 1
			PORTD = patron[millar];
			__delay_ms(1);

			PORTC = 0b11111101; // Display 2
			PORTD = patron[centena];
			__delay_ms(1);

			PORTC = 0b11111011; // Display 3
			PORTD = patron[decena];
			__delay_ms(1);

			PORTC = 0b11110111; // Display 4
			PORTD = patron[unidad];
			__delay_ms(1);
		}

		num++;

		if(num == 10000){
			num = 0;
		}
	}
}
