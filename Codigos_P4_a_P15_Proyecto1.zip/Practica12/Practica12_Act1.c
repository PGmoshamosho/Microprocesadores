#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};

char Leer_Teclado_Raw(){
    TRISD = 0xF0;


    PORTD = 0b00001110;
    __delay_ms(5);

    if(PORTDbits.RD4 == 0) return '1';
    if(PORTDbits.RD5 == 0) return '2';
    if(PORTDbits.RD6 == 0) return '3';
    if(PORTDbits.RD7 == 0) return 'A';


    PORTD = 0b00001101;
    __delay_ms(5);

    if(PORTDbits.RD4 == 0) return '4';
    if(PORTDbits.RD5 == 0) return '5';
    if(PORTDbits.RD6 == 0) return '6';
    if(PORTDbits.RD7 == 0) return 'B';


    PORTD = 0b00001011;
    __delay_ms(5);

    if(PORTDbits.RD4 == 0) return '7';
    if(PORTDbits.RD5 == 0) return '8';
    if(PORTDbits.RD6 == 0) return '9';
    if(PORTDbits.RD7 == 0) return 'C';


    PORTD = 0b00000111;
    __delay_ms(5);

    if(PORTDbits.RD4 == 0) return '*';
    if(PORTDbits.RD5 == 0) return '0';
    if(PORTDbits.RD6 == 0) return '#';
    if(PORTDbits.RD7 == 0) return 'D';

    return 0;
}

char Leer_Teclado(){
    char tecla1, tecla2;

    tecla1 = Leer_Teclado_Raw();

    if(tecla1 != 0){
        __delay_ms(50);
        tecla2 = Leer_Teclado_Raw();

        if(tecla1 == tecla2){
            while(Leer_Teclado_Raw() != 0);
            __delay_ms(50);
            return tecla1;
        }
    }

    return 0;
}

void Mostrar_Tecla(char tecla){
    LCD_Clear();

    LCD_Set_Cursor(0,0);
    LCD_putrs("Tecla:");

    LCD_Set_Cursor(1,0);
    LCD_putc(tecla);
}

void main(void){
    char tecla;

    ANSEL = 0x00;
    ANSELH = 0x00;

    TRISD = 0xF0;
    PORTD = 0xFF;

    LCD_Init(lcd);
    LCD_Clear();

    LCD_Set_Cursor(0,0);
    LCD_putrs("Presiona tecla");

    while(1){
        tecla = Leer_Teclado();

        if(tecla != 0){
            Mostrar_Tecla(tecla);
        }
    }
}
