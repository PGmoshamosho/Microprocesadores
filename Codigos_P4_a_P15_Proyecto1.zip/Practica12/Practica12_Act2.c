#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};

char Leer_Teclado_Raw(){
    TRISD = 0xF0;

    PORTD = 0b00001110;
    __delay_ms(5);
    if(PORTDbits.RD4 == 0) return '1';
    if(PORTDbits.RD5 == 0) return '2';
    if(PORTDbits.RD6 == 0) return '3';
    if(PORTDbits.RD7 == 0) return 'A';

    PORTD = 0b00001101;
    __delay_ms(5);
    if(PORTDbits.RD4 == 0) return '4';
    if(PORTDbits.RD5 == 0) return '5';
    if(PORTDbits.RD6 == 0) return '6';
    if(PORTDbits.RD7 == 0) return 'B';

    PORTD = 0b00001011;
    __delay_ms(5);
    if(PORTDbits.RD4 == 0) return '7';
    if(PORTDbits.RD5 == 0) return '8';
    if(PORTDbits.RD6 == 0) return '9';
    if(PORTDbits.RD7 == 0) return 'C';

    PORTD = 0b00000111;
    __delay_ms(5);
    if(PORTDbits.RD4 == 0) return '*';
    if(PORTDbits.RD5 == 0) return '0';
    if(PORTDbits.RD6 == 0) return '#';
    if(PORTDbits.RD7 == 0) return 'D';

    return 0;
}

char Leer_Teclado(){
    char tecla1, tecla2;

    tecla1 = Leer_Teclado_Raw();

    if(tecla1 != 0){
        __delay_ms(50);
        tecla2 = Leer_Teclado_Raw();

        if(tecla1 == tecla2){
            while(Leer_Teclado_Raw() != 0);
            __delay_ms(50);
            return tecla1;
        }
    }

    return 0;
}

void Pantalla_Inicio(){
    LCD_Clear();
    LCD_Set_Cursor(0,0);
    LCD_putrs("Calculadora:");
    LCD_Set_Cursor(1,0);
}

void main(void){
    char tecla;
    char operador = 0;
    char buffer[16];

    long num1 = 0;
    long num2 = 0;
    long resultado = 0;
    long decimal = 0;
    long entero = 0;
    long decimales = 0;

    unsigned char estado = 1;
    unsigned char resultado_mostrado = 0;

    ANSEL = 0x00;
    ANSELH = 0x00;

    TRISD = 0xF0;
    PORTD = 0xFF;

    LCD_Init(lcd);
    Pantalla_Inicio();

    while(1){
        tecla = Leer_Teclado();

        if(tecla != 0){

            if(tecla >= '0' && tecla <= '9'){

                if(resultado_mostrado == 1){
                    num1 = 0;
                    num2 = 0;
                    resultado = 0;
                    operador = 0;
                    estado = 1;
                    resultado_mostrado = 0;
                    Pantalla_Inicio();
                }

                LCD_putc(tecla);

                if(estado == 1){
                    num1 = (num1 * 10) + (tecla - '0');
                }
                else if(estado == 2){
                    num2 = (num2 * 10) + (tecla - '0');
                }
            }

            else if(tecla == 'A'){
                if(resultado_mostrado == 0){
                    operador = '+';
                    estado = 2;
                    LCD_putc('+');
                }
            }

            else if(tecla == 'B'){
                if(resultado_mostrado == 0){
                    operador = '-';
                    estado = 2;
                    LCD_putc('-');
                }
            }

            else if(tecla == 'C'){
                if(resultado_mostrado == 0){
                    operador = '*';
                    estado = 2;
                    LCD_putc('*');
                }
            }

            else if(tecla == 'D'){
                if(resultado_mostrado == 0){
                    operador = '/';
                    estado = 2;
                    LCD_putc('/');
                }
            }

            else if(tecla == '#'){
                LCD_Clear();

                LCD_Set_Cursor(0,0);
                LCD_putrs("Resultado:");

                LCD_Set_Cursor(1,0);

                if(operador == '+'){
                    resultado = num1 + num2;
                    sprintf(buffer, "%ld+%ld=%ld", num1, num2, resultado);
                    LCD_putrs(buffer);
                }

                else if(operador == '-'){
                    resultado = num1 - num2;
                    sprintf(buffer, "%ld-%ld=%ld", num1, num2, resultado);
                    LCD_putrs(buffer);
                }

                else if(operador == '*'){
                    resultado = num1 * num2;
                    sprintf(buffer, "%ld*%ld=%ld", num1, num2, resultado);
                    LCD_putrs(buffer);
                }

                else if(operador == '/'){
                    if(num2 == 0){
                        LCD_putrs("Error div 0");
                    }
                    else{
                        decimal = (num1 * 100) / num2;
                        entero = decimal / 100;
                        decimales = decimal % 100;

                        sprintf(buffer, "%ld/%ld=%ld.%02ld", num1, num2, entero, decimales);
                        LCD_putrs(buffer);
                    }
                }

                else{
                    LCD_putrs("Error");
                }

                resultado_mostrado = 1;
            }

            else if(tecla == '*'){
                num1 = 0;
                num2 = 0;
                resultado = 0;
                operador = 0;
                estado = 1;
                resultado_mostrado = 0;
                Pantalla_Inicio();
            }
        }
    }
}
