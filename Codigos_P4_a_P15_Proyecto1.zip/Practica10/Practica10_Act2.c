#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

volatile unsigned int tiempo = 0;
volatile unsigned int contador = 0;

char exec[6];
char voltaje_txt[8];

void Timer1_Init(){
    T1CON = 0x31;

    TMR1H = 0xF6;
    TMR1L = 0x3C;

    TMR1IF = 0;
    TMR1IE = 1;
    PEIE = 1;
    GIE = 1;
}

void ADC_Init(){
    ANSEL = 0x01;
    ANSELH = 0x00;

    TRISAbits.TRISA0 = 1;

    ADCON0 = 0x81;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(){
    __delay_us(5);
    GO_nDONE = 1;
    while(GO_nDONE);
    return ((ADRESH << 8) + ADRESL);
}

void __interrupt() ISR(void){
    if(TMR1IF){
        TMR1H = 0xF6;
        TMR1L = 0x3C;

        contador++;

        if(contador > 100){
            tiempo++;
            contador = 0;
        }

        TMR1IF = 0;
    }
}

void main(void){
    unsigned int adc;
    unsigned int voltaje_mv;

    Timer1_Init();
    ADC_Init();

    LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};
    LCD_Init(lcd);
    LCD_Clear();

    LCD_Set_Cursor(0, 0);
    LCD_putrs("Voltaje: ");

    while(1){
        adc = ADC_Read();

        voltaje_mv = (adc * 5000UL) / 1023;

        LCD_Set_Cursor(1, 0);
        sprintf(voltaje_txt, "%u.%02uV", voltaje_mv / 1000, (voltaje_mv % 1000) / 10);
        LCD_putrs(voltaje_txt);

        LCD_Set_Cursor(1, 11);
        sprintf(exec, "%02u:%02u", tiempo / 60, tiempo % 60);
        LCD_putrs(exec);

        __delay_ms(100);
    }
}
