#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

unsigned char copa[8] = {
    0x0E,
    0x1F,
    0x15,
    0x1F,
    0x0E,
    0x04,
    0x0E,
    0x1F
};


unsigned char estrella[8] = {
    0x04,
    0x15,
    0x0E,
    0x1F,
    0x0E,
    0x15,
    0x04,
    0x00
};

void ADC_Init(){

    ANSEL = 0x03;
    ANSELH = 0x00;

    ADCON0 = 0x81;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(unsigned char channel){

    ADCON0 &= 0x83;
    ADCON0 |= channel << 2;
    __delay_ms(5);

    GO_nDONE = 1;

    while(GO_nDONE);
    return((ADRESH << 8) + ADRESL);
}

void Crear_Caracter(unsigned char posicion, unsigned char dibujo[]){
    unsigned char i;
    LCD_Cmd(0x40 + (posicion * 8));

    for(i = 0; i < 8; i++){
        LCD_putc(dibujo[i]);
    }

    LCD_Cmd(0x80);
}

void main(void){
    LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};
    unsigned int adc_x;
    unsigned int adc_y;
    unsigned char columna = 7;
    unsigned char fila = 0;
    unsigned char animacion = 0;
    unsigned char estado_anterior = 1;

    ADC_Init();
    TRISBbits.TRISB0 = 1;
    OPTION_REGbits.nRBPU = 0;
    WPUBbits.WPUB0 = 1;

    LCD_Init(lcd);
    Crear_Caracter(0, copa);
    Crear_Caracter(1, estrella);

    while(1){
        adc_x = ADC_Read(0);
        adc_y = ADC_Read(1);

        if(adc_x > 600){
            columna++;
            if(columna > 15){
                columna = 0;
            }
        }
        else if(adc_x < 400){
            if(columna == 0){
                columna = 15;
            }

            else{
                columna--;
            }
        }

        if(adc_y < 400){
            fila = 0;
        }
        else if(adc_y > 600){
            fila = 1;
        }

        if(PORTBbits.RB0 == 0 && estado_anterior == 1){
            __delay_ms(50);

            if(PORTBbits.RB0 == 0){
                animacion++;

                if(animacion > 1){
                    animacion = 0;
                }
                while(PORTBbits.RB0 == 0);
                __delay_ms(50);
            }
        }
        estado_anterior = PORTBbits.RB0;

        LCD_Clear();
        LCD_Set_Cursor(fila,columna);
        if(animacion == 0){

            LCD_putc(0);
        }
        else{
            LCD_putc(1);
        }
        __delay_ms(150);
    }

}
