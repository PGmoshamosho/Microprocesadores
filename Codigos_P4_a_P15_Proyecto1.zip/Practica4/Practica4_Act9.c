#include <xc.h>

#pragma config FOSC = XT
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

unsigned char Estado1, Estado2, Estado3;
unsigned char contador = 0;

unsigned char numeros[10] = {
    0b00111111, // 0
    0b00000110, // 1
    0b01011011, // 2
    0b01001111, // 3
    0b01100110, // 4
    0b01101101, // 5
    0b01111101, // 6
    0b00000111, // 7
    0b01111111, // 8
    0b01101111  // 9
};

void mostrarNumero(unsigned char numero){
    unsigned char unidades;
    unsigned char decenas;

    unidades = numero % 10;
    decenas = numero / 10;

    PORTD = numeros[decenas];
    PORTC = numeros[unidades];
}

void main(void){
    ANSEL = 0;
    ANSELH = 0;

    OPTION_REG = OPTION_REG & 0b01111111;

    TRISB = 0xFF;
    TRISD = 0x00;
    TRISC = 0x00;

    PORTD = 0x00;
    PORTC = 0x00;

    while(1){

        mostrarNumero(contador);

        if(PORTBbits.RB0 == 0){
            __delay_ms(200);
            contador++;

            if(contador > 99){
                contador = 0;
            }

            while(PORTBbits.RB0 == 0);
        }

        if(PORTBbits.RB1 == 0){
            __delay_ms(200);

            if(contador == 0){
                contador = 99;
            }
            else{
                contador--;
            }

            while(PORTBbits.RB1 == 0);
        }

        if(PORTBbits.RB2 == 0){
            __delay_ms(200);
            contador = 0;

            while(PORTBbits.RB2 == 0);
        }
    }
}
