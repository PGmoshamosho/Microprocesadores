#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

void ADC_Init(){
    ANSEL = 0x03;
    ANSELH = 0x00;

    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA1 = 1;

    ADCON0 = 0x01;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(unsigned char channel){
    __delay_ms(5);

    ADCON0 &= 0x83;
    ADCON0 |= channel << 2;

    __delay_ms(2);

    GO_nDONE = 1;
    while(GO_nDONE);

    return((ADRESH << 8) + ADRESL);
}

void main(void){
    char buffer1[16];
    char buffer2[16];

    unsigned int adc_result1;
    unsigned int adc_result2;

    unsigned int volt1;
    unsigned int volt2;

    unsigned int part_ent1;
    unsigned int part_dec1;

    unsigned int part_ent2;
    unsigned int part_dec2;

    ADC_Init();

    LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};
    LCD_Init(lcd);

    while(1){
        adc_result1 = ADC_Read(0);
        adc_result2 = ADC_Read(1);

        volt1 = (adc_result1 * 5000) / 1023;
        volt2 = (adc_result2 * 5000) / 1023;

        part_ent1 = volt1 / 1000;
        part_dec1 = volt1 % 1000;

        part_ent2 = volt2 / 1000;
        part_dec2 = volt2 % 1000;

        LCD_Clear();

        LCD_Set_Cursor(0,0);
        sprintf(buffer1, "Voltaje 1:%u.%03u", part_ent1, part_dec1);
        LCD_putrs(buffer1);

        LCD_Set_Cursor(1,0);
        sprintf(buffer2, "Voltaje 2:%u.%03u", part_ent2, part_dec2);
        LCD_putrs(buffer2);

        __delay_ms(300);
    }
}
