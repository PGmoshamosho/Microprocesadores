#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

void ADC_Init(){
    ANSEL = 0x03;
    ANSELH = 0x00;

    ADCON0 = 0x81;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(unsigned char channel){
    ADCON0 &= 0x83;
    ADCON0 |= channel << 2;

    __delay_ms(5);

    GO_nDONE = 1;
    while(GO_nDONE);

    return((ADRESH << 8) + ADRESL);
}

void main(void){
    ADC_Init();

    TRISBbits.TRISB0 = 1;
    TRISBbits.TRISB1 = 1;

    OPTION_REGbits.nRBPU = 0;
    WPUBbits.WPUB0 = 1;
    WPUBbits.WPUB1 = 1;

    LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};
    LCD_Init(lcd);

    char buffer1[16];
    char buffer2[16];

    unsigned char modo1 = 0;
    unsigned char modo2 = 0;

    unsigned char estado_anterior1 = 1;
    unsigned char estado_anterior2 = 1;

    while(1){

        if(PORTBbits.RB0 == 0 && estado_anterior1 == 1){
            __delay_ms(50);

            if(PORTBbits.RB0 == 0){
                modo1++;

                if(modo1 > 2){
                    modo1 = 0;
                }

                while(PORTBbits.RB0 == 0);
                __delay_ms(50);
            }
        }

        if(PORTBbits.RB1 == 0 && estado_anterior2 == 1){
            __delay_ms(50);

            if(PORTBbits.RB1 == 0){
                modo2++;

                if(modo2 > 2){
                    modo2 = 0;
                }

                while(PORTBbits.RB1 == 0);
                __delay_ms(50);
            }
        }

        estado_anterior1 = PORTBbits.RB0;
        estado_anterior2 = PORTBbits.RB1;

        unsigned int adc_result1 = ADC_Read(0);
        unsigned int adc_result2 = ADC_Read(1);

        LCD_Clear();

        LCD_Set_Cursor(0,0);

        if(modo1 == 0){
            unsigned long volt1 = ((unsigned long)adc_result1 * 50000) / 1023;
            unsigned int part_int1 = volt1 / 10000;
            unsigned int part_dec1 = volt1 % 10000;

            sprintf(buffer1, "V1:%u.%04uV", part_int1, part_dec1);
            LCD_putrs(buffer1);
        }
        else if(modo1 == 1){
            unsigned int porcentaje1 = ((unsigned long)adc_result1 * 100) / 1023;

            sprintf(buffer1, "P1:%u %%", porcentaje1);
            LCD_putrs(buffer1);
        }
        else{
            sprintf(buffer1, "ADC1:%u", adc_result1);
            LCD_putrs(buffer1);
        }

        LCD_Set_Cursor(1,0);

        if(modo2 == 0){
            unsigned long volt2 = ((unsigned long)adc_result2 * 50000) / 1023;
            unsigned int part_int2 = volt2 / 10000;
            unsigned int part_dec2 = volt2 % 10000;

            sprintf(buffer2, "V2:%u.%04uV", part_int2, part_dec2);
            LCD_putrs(buffer2);
        }
        else if(modo2 == 1){
            unsigned int porcentaje2 = ((unsigned long)adc_result2 * 100) / 1023;

            sprintf(buffer2, "P2:%u %%", porcentaje2);
            LCD_putrs(buffer2);
        }
        else{
            sprintf(buffer2, "ADC2:%u", adc_result2);
            LCD_putrs(buffer2);
        }

        __delay_ms(200);
    }
}
