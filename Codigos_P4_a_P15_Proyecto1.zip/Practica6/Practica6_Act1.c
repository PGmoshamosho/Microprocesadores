#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

unsigned char copa[8] = {
    0x0E,
    0x1F,
    0x15,
    0x1F,
    0x0E,
    0x04,
    0x0E,
    0x1F
};

unsigned char estrella[8] = {
    0x04,
    0x15,
    0x0E,
    0x1F,
    0x0E,
    0x15,
    0x04,
    0x00
};

unsigned char corazon[8] = {
    0x00,
    0x0A,
    0x1F,
    0x1F,
    0x1F,
    0x0E,
    0x04,
    0x00
};

void Crear_Caracter(unsigned char posicion, unsigned char caracter[]){
    unsigned char i;

    LCD_Cmd(0x40 + (posicion * 8));

    for(i = 0; i < 8; i++){
        LCD_putc(caracter[i]);
    }

    LCD_Cmd(0x80);
}

void Mostrar_Mensaje(unsigned char figura){

    LCD_Clear();

    LCD_Set_Cursor(0,0);
    LCD_putrs("Campeon");

    LCD_Set_Cursor(1,0);
    LCD_putrs("MEXICO!! ");
    LCD_putc(figura);
}

void main(void){

    unsigned char estado;
    unsigned char boton_anterior;

    LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};

    ANSEL = 0x00;
    ANSELH = 0x00;

    estado = 0;
    boton_anterior = 1;

    TRISBbits.TRISB0 = 1;

    OPTION_REGbits.nRBPU = 0;
    WPUBbits.WPUB0 = 1;

    LCD_Init(lcd);

    Crear_Caracter(0, copa);
    Crear_Caracter(1, estrella);
    Crear_Caracter(2, corazon);

    Mostrar_Mensaje(0);

    while(1){

        if(PORTBbits.RB0 == 0 && boton_anterior == 1){
            __delay_ms(50);

            if(PORTBbits.RB0 == 0){

                estado++;

                if(estado > 2){
                    estado = 0;
                }

                Mostrar_Mensaje(estado);
            }
        }

        boton_anterior = PORTBbits.RB0;
    }
}
