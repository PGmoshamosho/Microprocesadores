#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

void main(void){

    char c;
    LCD display = {&PORTC, 2, 3, 4, 5, 6, 7};

    ANSEL = 0x00;
    ANSELH = 0x00;
    PORTC = 0x00;

    LCD_Init(display);

    while(1){

        LCD_Clear();
        LCD_Set_Cursor(0,0);
        LCD_putrs(" HELLO WORLD! ");

        LCD_Set_Cursor(1,0);

        for(c = 'A'; c < 'Q'; c++){
            LCD_putc(c);
            __delay_ms(300);
        }

        __delay_ms(1000);
    }
}
