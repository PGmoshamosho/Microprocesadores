#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lcd.h"

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

void ADC_Init(){
    ANSEL = 0x01;
    ANSELH = 0x00;

    ADCON0 = 0x81;
    ADCON1 = 0x80;
}

unsigned int ADC_Read(){
    __delay_us(5);
    GO_nDONE = 1;
    while(GO_nDONE);
    return((ADRESH << 8) + ADRESL);
}

void main(void){
    ADC_Init();

    TRISBbits.TRISB0 = 1;
    OPTION_REGbits.nRBPU = 0;
    WPUBbits.WPUB0 = 1;

    LCD lcd = {&PORTC, 2, 3, 4, 5, 6, 7};
    LCD_Init(lcd);

    char buffer[16];
    unsigned char modo = 0;
    unsigned char estado_anterior = 1;

    while(1){

        if(PORTBbits.RB0 == 0 && estado_anterior == 1){
            __delay_ms(50);

            if(PORTBbits.RB0 == 0){
                modo++;

                if(modo > 2){
                    modo = 0;
                }

                while(PORTBbits.RB0 == 0);
                __delay_ms(50);
            }
        }

        estado_anterior = PORTBbits.RB0;

        unsigned int adc_result = ADC_Read();

        LCD_Clear();
        LCD_Set_Cursor(0,0);

        if(modo == 0){
            unsigned long volt = ((unsigned long)adc_result * 50000) / 1023;
            unsigned int part_int = volt / 10000;
            unsigned int part_dec = volt % 10000;

            LCD_putrs("Voltaje:");
            LCD_Set_Cursor(1,0);
            sprintf(buffer, "%u.%04u V", part_int, part_dec);
            LCD_putrs(buffer);
        }
        else if(modo == 1){
            unsigned int porcentaje = ((unsigned long)adc_result * 100) / 1023;

            LCD_putrs("Porcentaje:");
            LCD_Set_Cursor(1,0);
            sprintf(buffer, "%u %%", porcentaje);
            LCD_putrs(buffer);
        }
        else{
            LCD_putrs("ADC:");
            LCD_Set_Cursor(1,0);
            sprintf(buffer, "%u", adc_result);
            LCD_putrs(buffer);
        }

        __delay_ms(200);
    }
}
