#include <xc.h>

#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 8000000

void Servo_Izquierda(){
    for(unsigned char i = 0; i < 25; i++){
        PORTCbits.RC0 = 1;
        __delay_us(600);
        PORTCbits.RC0 = 0;
        __delay_ms(20);
    }
}


void Servo_Derecha(){
    for(unsigned char i = 0; i < 25; i++){
        PORTCbits.RC0 = 1;
        __delay_us(2400);
        PORTCbits.RC0 = 0;
        __delay_ms(20);
    }
}

void main(void){
    ANSEL = 0x00;
    ANSELH = 0x00;

    TRISCbits.TRISC0 = 0;
    PORTCbits.RC0 = 0;

    while(1){
        Servo_Izquierda(); // -90 aprox
        __delay_ms(500);


        Servo_Derecha(); // +90 aprox
        __delay_ms(500);


    }
}
